package org.example;

public class Entities {

    public String URL = "https://www.takealot.com/";
    public String searchBar =  "//*[@id=\"shopfront-app\"]/header/div/div/div[2]/form/div/div[1]/input";
    public String searchButton = "//*[@id=\"shopfront-app\"]/header/div/div/div[2]/form/div/div[3]/button";
    public  String addCart = "//*[@id=\"71784268\"]/div/div[4]/div/button";
    public String SearchInput = "Play Station 5";
    public String Trolley = "//*[@id=\"shopfront-app\"]/div[2]/div/div/div[2]/div/div[2]/div/div/div/div/button";
    public String checkOut = "//*[@id=\"shopfront-app\"]/div[3]/div[2]/section/div[2]/div[2]/div/div[1]/div[1]/div/div[2]/a";
    public String Path = "C:/Users/CQ/Documents/report/";

    public String ButtonF = "//*[@id=\"menu-item-46271\"]/a";
}
